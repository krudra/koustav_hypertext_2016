This is sample place file. Each line contains one place name. Prepare this disctionary before running the code. If you need full place repo, drop a mail.
